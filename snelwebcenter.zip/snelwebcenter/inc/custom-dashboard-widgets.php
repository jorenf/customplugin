<?php

function remove_dashboard_widgets() {
    global $wp_meta_boxes;

    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_activity']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_drafts']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']);

}


add_action('wp_dashboard_setup', 'remove_dashboard_widgets' );

add_action( 'admin_footer', 'rv_custom_dashboard_widget' );
function rv_custom_dashboard_widget() {
	// Admin pannel gegevens snelwebcenter
	if ( get_current_screen()->base !== 'dashboard' ) {
		return;
	}
	?>

	<div id="custom-id" class="welcome-panel" style="display: none;">
		<div class="welcome-panel-content">
			<img src="https://www.snelwebcenter.nl/wp-content/uploads/2018/12/snelwebcenter-logo.svg" width="300px">
			<div class="welcome-panel-column-container">
				<div class="welcome-panel-column">
					<h3>Contactgegevens</h3>
                    <ul>
                        <li>Snelwebcenter</li>
                        <li>Odenseweg 4</li>
                        <li>9723 HA Groningen</li>
                        <li>T: <a href="tel:0592670112">085 016 0922</li>
                    </ul>
				</div>
				<!-- admin pannel gegevens waar nu divi staat -->
				<div class="welcome-panel-column">
					<h3>Divi</h3>
					<ul>
						<li><a target="_blank" href="https://www.elegantthemes.com/documentation/divi/">Divi documentatie</a></li>
						<li><a target="_blank" href="https://www.elegantthemes.com/documentation/divi-builder/">Divi Builder</a></li>
                        <li><a target="_blank" href="https://www.elegantthemes.com/documentation/divi/basics/">Leer de basis van Divi</a></li>
                        <li><a target="_blank" href="https://www.youtube.com/channel/UCuasRuWliU48RwnKXf9GesA">Leer op basis van video's</a></li>
					</ul>
				</div>
				<div class="welcome-panel-column welcome-panel-last">

				</div>
			</div>
		</div>
	</div>
	<script>
		jQuery(document).ready(function($) {
			$('#welcome-panel').after($('#custom-id').show());
		});
	</script>

<?php }
