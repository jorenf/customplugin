<?php
/**
 * This file represents an example of the code that themes would use to register
 * the required plugins.
 *
 * It is expected that theme authors would copy and paste this code into their
 * functions.php file, and amend to suit.
 *
 * @see http://tgmpluginactivation.com/configuration/ for detailed documentation.
 *
 * @package    TGM-Plugin-Activation
 * @subpackage Example
 * @version    2.6.1 for plugin Vantuinen Webdesign
 * @author     Thomas Griffin, Gary Jones, Juliette Reinders Folmer
 * @copyright  Copyright (c) 2011, Thomas Griffin
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       https://github.com/TGMPA/TGM-Plugin-Activation
 */

require_once dirname( __FILE__ ) . '/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'snelwebcenter_register_required_plugins' );

function snelwebcenter_register_required_plugins() {

	$plugins = array(

		// Plugins die geinstalleerd kunnen worden via wordpress hier
		array(
			'name'      => 'Google analytics for Wordpress',
			'slug'      => 'google-analytics-for-wordpress',
			'required'  => true,
		),

        array(
            'name'      => 'Yoast SEO',
            'slug'      => 'wordpress-seo',
            'required'  => true,
        ),

        array(
            'name'      => 'Comprimeer JPEG & PNG afbeeldingen',
            'slug'      => 'tiny-compress-images',
            'required'  => true,
        ),
		//Plugins die betaald zijn en apart geinstaleerd moeten word via een zip doe je hier. Zet de zip van de plugins in inc/plugins
		array(
			'name'               => 'Divi Builder', // De plugin naam.
			'slug'               => 'divi-builder', // De naam van het zip bestandje
			'source'             => dirname( __FILE__ ) . '/plugins/divi-builder.zip', // De naam van het zip bestandje in de plugin map
			'required'           => true, // is de plugin required
			'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher. If the plugin version is higher than the plugin version installed, the user will be notified to update the plugin.
			'force_activation'   => true, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
			'force_deactivation' => true, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			'external_url'       => '', // If set, overrides default API URL and points to an external URL.
			'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		),

	);

	tgmpa( $plugins );
}
