<?php

// Dit verandert het logo van de login pagina
function snelwebcenter_login_logo()
{
    echo '<link rel="stylesheet" type="text/css" href="' . PLUGIN_PATH . '/assets/css/main.css" />';
}
add_action('login_head', 'snelwebcenter_login_logo');

// Dit verandert de url van het logo
function snelwebcenter_login_logo_url($url)
{
    return 'https://www.snelwebcenter.nl/';
}
add_filter( 'login_headerurl', 'snelwebcenter_login_logo_url' );

//Dit verandert de title van het logo
function snelwebcenter_login_logo_title()
{
    return 'Snelwebcenter Logo';
}
add_filter( 'login_headertitle', 'snelwebcenter_login_logo_title' );

//Dit wijzigt de foutmelding
function login_error_override()
{
    return 'Ongeldige inlog gegevens';
}
add_filter('login_errors', 'login_error_override');

//Dit zorgt ervoor dat de onthoud me knop, altijd gecheckt is
function login_checked_remember_me()
{
    add_filter( 'login_footer', 'rememberme_checked' );
}
add_action( 'init', 'login_checked_remember_me' );

function rememberme_checked()
{
    echo "<script>document.getElementById('rememberme').checked = true;</script>";
}
