<?php
/*
Plugin Name:  SnelWebCenter
Plugin URI:   https://www.snelwebcenter.nl/
Description:  Standaard plugin voor websites SnelwebCenter
Version:      1.0.1
Author:       SnelwebCenter
Author URI:   https://www.snelwebcenter.nl/
*/

define( 'PLUGIN_PATH', plugin_dir_url( __FILE__ ) );

require_once 'inc/custom-plugins-install.php';

require_once 'inc/custom-dashboard-widgets.php';
require_once 'inc/custom-login-page.php';

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
     die;
}

function change_admin_footer(){
	 echo '<span id="footer-thankyou">Realisatie: <a style="text-decoration: none;" href="https://www.snelwebcenter.nl/" target="_blank">SnelwebCenter</a></span>';
}
add_filter('admin_footer_text', 'change_admin_footer');

function custom_menu_color() {
  echo '<style>
    #adminmenu, #adminmenu, #adminmenuback, #adminmenuwrap, #wpadminbar {
        background-color: #173341;
    }
    #adminmenu .wp-has-current-submenu .wp-submenu {
        background-color: #173341;
    }
    #adminmenu .wp-submenu a:hover {
        color: #ffffff;
    }
    #adminmenu li.menu-top:hover, #adminmenu li.opensub>a.menu-top, #adminmenu li>a.menu-top:focus {
        background-color: #24a2c8;
    }
    #adminmenu .wp-submenu, .folded #adminmenu .wp-has-current-submenu .wp-submenu, .folded #adminmenu a.wp-has-current-submenu:focus+.wp-submenu {
        background-color: #24a2c8;
    }
    #adminmenu li.wp-has-submenu.wp-not-current-submenu:hover:after, #adminmenu li.wp-has-submenu.wp-not-current-submenu.opensub:hover:after {
        border-right-color: #24a2c8;
    }
  </style>';
}
add_action('admin_head', 'custom_menu_color');

// Remove WP Version From Styles
add_filter( 'style_loader_src', 'sdt_remove_ver_css_js', 9999 );
// Remove WP Version From Scripts
add_filter( 'script_loader_src', 'sdt_remove_ver_css_js', 9999 );

// Function to remove version numbers
function sdt_remove_ver_css_js( $src ) {
	if ( strpos( $src, 'ver=' ) )
		$src = remove_query_arg( 'ver', $src );
	return $src;
}
